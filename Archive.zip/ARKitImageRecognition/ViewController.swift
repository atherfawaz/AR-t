//
//  ViewController.swift
//  Image Recognition
//
//  Created by Jayven Nhan on 3/20/18.
//  Copyright © 2018 Jayven Nhan. All rights reserved.
//

import UIKit
import ARKit
import AVFoundation

var isAr = false

class ViewController: UIViewController {
    
    @IBOutlet weak var btnLang: UIButton!
    @IBOutlet weak var sceneView: ARSCNView!
    
    let fadeDuration: TimeInterval = 0.3
    
    lazy var fadeAndSpinAction: SCNAction = {
        return .sequence([
            .fadeIn(duration: fadeDuration)
            ])
    }()
    
    lazy var scaleToZero : SCNAction = {
        return .sequence([.scale(to: 0, duration: fadeDuration)])
    }()
    lazy var fadeOut : SCNAction = {
        return .sequence([.fadeOut(duration: fadeDuration)])
    }()
//
    
    
//    lazy var treeNode: SCNNode = {
//        guard let scene = SCNScene(named: "house_obj.scn"),
//            let node = scene.rootNode.childNode(withName: "house_obj", recursively: false) else { return SCNNode() }
//        let scaleFactor = 0.0000811//0.0000630 / 10
//        node.scale = SCNVector3(scaleFactor, scaleFactor, scaleFactor)
//        //node.eulerAngles.x = -.pi / 2
//        return node
//    }()
//
//    lazy var bookNode: SCNNode = {
//        guard let scene = SCNScene(named: "book.scn"),
//            let node = scene.rootNode.childNode(withName: "book", recursively: false) else { return SCNNode() }
//        let scaleFactor  = 0.1
//        node.scale = SCNVector3(scaleFactor, scaleFactor, scaleFactor)
//        return node
//    }()
//
//    lazy var mountainNode: SCNNode = {
//        guard let scene = SCNScene(named: "mountain.scn"),
//            let node = scene.rootNode.childNode(withName: "mountain", recursively: false) else { return SCNNode() }
//        let scaleFactor  = 0.25
//        node.scale = SCNVector3(scaleFactor, scaleFactor, scaleFactor)
//        node.eulerAngles.x += -.pi / 2
//        return node
//    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btnLang.layer.shadowColor = UIColor.black.cgColor
        btnLang.layer.shadowOffset = CGSize.zero
        btnLang.layer.shadowOpacity = 0.1
        btnLang.layer.shadowRadius = 5
        sceneView.delegate = self
        configureLighting()
        setDefaults(scene: sceneView.scene)
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ViewController.didTap(withGestureRecognizer:)))
        sceneView.addGestureRecognizer(tapGestureRecognizer)
    }
    
    func configureLighting() {
        sceneView.autoenablesDefaultLighting = true
        sceneView.automaticallyUpdatesLighting = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if isAr {
            btnLang.setImage(UIImage(named: "uae"), for: .normal)
        }
        resetTrackingConfiguration()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }
    
    @IBAction func resetButtonDidTouch(_ sender: UIBarButtonItem) {
        resetTrackingConfiguration()
    }
    
    func resetTrackingConfiguration() {
        guard let referenceImages = ARReferenceImage.referenceImages(inGroupNamed: "AR Resources", bundle: nil) else { return }
        let configuration = ARWorldTrackingConfiguration()
        configuration.detectionImages = referenceImages
        configuration.planeDetection = .vertical
        let options: ARSession.RunOptions = [.resetTracking, .removeExistingAnchors]
        sceneView.session.run(configuration, options: options)
    }
    
    func setDefaults(scene: SCNScene) {
        
        let ambientLightNode = SCNNode()
        ambientLightNode.light = SCNLight()
        ambientLightNode.light?.type = SCNLight.LightType.ambient
        ambientLightNode.light?.color = UIColor(white: 0.6, alpha: 1.0)
        scene.rootNode.addChildNode(ambientLightNode)
        
        // Create a directional light with an angle to provide a more interesting look
        let directionalLight = SCNLight()
        directionalLight.type = .directional
        directionalLight.color = UIColor(white: 0.8, alpha: 1.0)
        directionalLight.shadowRadius = 5.0
        directionalLight.shadowColor = UIColor.black.withAlphaComponent(0.6)
        directionalLight.castsShadow = true
        directionalLight.shadowMode = .deferred
        let directionalNode = SCNNode()
        directionalNode.eulerAngles = SCNVector3Make(GLKMathDegreesToRadians(-40), GLKMathDegreesToRadians(0), GLKMathDegreesToRadians(0))
        directionalNode.light = directionalLight
        scene.rootNode.addChildNode(directionalNode)
    }
    
    var isPlaying = false
    @objc func didTap(withGestureRecognizer recognizer: UIGestureRecognizer) {
        let tapLocation = recognizer.location(in: sceneView)
        let hitTestResults = sceneView.hitTest(tapLocation)
        guard let node = hitTestResults.first?.node else { return }
        if node == PlayButtonP1 || node == PlayButtonP2 {
            print("detected")
            playStart()
            for x in [PlayButtonP1, PlayButtonP2, titleNode, descriptionNode] {
                x.runAction(scaleToZero)
                x.runAction(fadeOut)
            }
            // play tap sound
            // play game
        } else if node == yesNode || node == noNode || node == yesNodeBg || node == noNodeBg {
            for x in [questionNode, yesNode, yesNodeBg, noNode, noNodeBg] {
                x.runAction(scaleToZero)
                x.runAction(fadeOut)
            }
            let box = SCNBox(width: 0.42, height: 0.01, length: 0.32, chamferRadius: 0.01)
            box.firstMaterial?.diffuse.contents = UIColor.black
            
            
            videoBg.geometry = box
            videoBg.opacity = 0
            
            videoBg.runAction(.sequence([.fadeOpacity(to: 1, duration: 0.2)]))
            theNode.addChildNode(videoBg)
            videoNode = SKVideoNode(fileNamed: isAr ? "arnew.mp4" : "ennew.mp4")
            let skScene = SKScene(size: CGSize(width: 1280, height: 720))
            skScene.addChild(videoNode)
            
            videoNode.position = CGPoint(x: skScene.size.width/2, y: skScene.size.height/2)
            videoNode.size = skScene.size
            
            let tvPlane = SCNPlane(width: 0.4, height: 0.3)
            tvPlane.firstMaterial?.diffuse.contents = skScene
            tvPlane.firstMaterial?.isDoubleSided = true
            
            
            tvPlaneNode = SCNNode(geometry: tvPlane)
//            var translation = matrix_identity_float4x4
//            translation.columns.3.z = -1.0
//            guard let currentFrame = self.sceneView.session.currentFrame else {
//                return
//            }
//            tvPlaneNode.simdTransform = matrix_multiply(currentFrame.camera.transform, translation)
//            tvPlaneNode.eulerAngles = SCNVector3(Double.pi,0,0)
            tvPlaneNode.runAction(.move(by: SCNVector3(0, 0.01, 0), duration: 0.1))
            tvPlaneNode.runAction(.rotateBy(x: CGFloat.pi/2, y: 0, z: -CGFloat.pi, duration: 0.2))
            theNode.addChildNode(tvPlaneNode)
            videoNode.play()
            isPlaying = true
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 18) {
                self.isPlaying = false
                tvPlaneNode.runAction(.fadeOpacity(to: 0.0001, duration: 0.3))
                videoBg.runAction(.fadeOpacity(to: 0.0001, duration: 0.3))
            }
        } else if node == tvPlaneNode {
            if !isPlaying {
                let p = videoNode.parent
                videoNode.removeFromParent()
                videoNode = SKVideoNode(fileNamed: isAr ? "arnew.mp4" : "ennew.mp4")
                videoNode.position = CGPoint(x: 1280/2, y: 720/2)
                videoNode.size = CGSize(width: 1280, height: 720)
                p?.addChild(videoNode)
                videoNode.play()
                tvPlaneNode.runAction(.fadeOpacity(to: 1, duration: 0.3))
                videoBg.runAction(.fadeOpacity(to: 1, duration: 0.3))
                isPlaying = true
                DispatchQueue.main.asyncAfter(deadline: .now() + 18) {
                    self.isPlaying = false
                    tvPlaneNode.runAction(.fadeOpacity(to: 0.0001, duration: 0.3))
                    videoBg.runAction(.fadeOpacity(to: 0.0001, duration: 0.3))
                }
            }
        }
        
    }
    
    func playStart() {
        guard let url = Bundle.main.url(forResource: "letsstart", withExtension: "wav") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            try AVAudioSession.sharedInstance().setActive(true)

            /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.wav.rawValue)
            
            /* iOS 10 and earlier require the following line:
             player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileTypeMPEGLayer3) */
            
            guard let player = player else { return }
            
            if !isAr { player.play() }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                questionNode = self.getText(isAr ? "هل كان برج بابل حقيقي؟" : "Was the tower of Babel real?")
                questionNode.opacity = 0
                questionNode.position.x -= 0.2
                questionNode.position.z += 0.22
                questionNode.scale = SCNVector3(0.02,0.02,0.02)
                questionNode.runAction(self.fadeAndSpinAction)
                theNode.addChildNode(questionNode)
                
                let box = SCNBox(width: 0.1, height: 0.01, length: 0.061, chamferRadius: 0.06)
                box.firstMaterial?.diffuse.contents = UIColor(hex: "#F0DEB4")
                
                yesNodeBg.geometry = box
                yesNodeBg.opacity = 0
                yesNodeBg.position = questionNode.position
                yesNodeBg.position.y -= 0.01
                yesNodeBg.position.z += 0.05
                yesNodeBg.position.z += 0.2
                yesNodeBg.position.x += 0.05
                yesNodeBg.runAction(.scale(to: 1, duration: 0.0001))
                yesNodeBg.runAction(.sequence([.fadeIn(duration: self.fadeDuration)]))
                yesNodeBg.runAction(.sequence([.move(by: SCNVector3(0, 0, -0.2), duration: 0.1)]))
                theNode.addChildNode(yesNodeBg)
                
                noNodeBg.geometry = box
                noNodeBg.opacity = 0
                noNodeBg.position = questionNode.position
                noNodeBg.position.y -= 0.01
                noNodeBg.position.z += 0.05
                noNodeBg.position.z += 0.2
                noNodeBg.position.x += 0.05 + 0.1 + 0.05
                noNodeBg.runAction(.scale(to: 1, duration: 0.0001))
                noNodeBg.runAction(.sequence([.fadeIn(duration: self.fadeDuration)]))
                noNodeBg.runAction(.sequence([.move(by: SCNVector3(0, 0, -0.2), duration: 0.1)]))
                theNode.addChildNode(noNodeBg)
                
                yesNode = self.getText(isAr ? "نعم" : "Yes", false, .green)
                yesNode.opacity = 0
                yesNode.position = yesNodeBg.position
                yesNode.position.z += 0.23
                yesNode.scale = SCNVector3(0.01,0.01,0.02)
                yesNode.position.y += 0.01
                yesNode.position.x -= 0.02
                yesNode.runAction(.sequence([.fadeIn(duration: self.fadeDuration)]))
                yesNode.runAction(.sequence([.scale(by: 2, duration: self.fadeDuration)]))
                yesNode.runAction(.sequence([.move(by: SCNVector3(0, 0, -0.405), duration: 0.1)]))
                theNode.addChildNode(yesNode)
                
                noNode = self.getText(isAr ? "لا" : "No", false, .red)
                noNode.opacity = 0
                noNode.position = noNodeBg.position
                noNode.scale = SCNVector3(0.01,0.01,0.02)
                noNode.position.y += 0.01
                noNode.position.z += 0.23
                noNode.position.x -= 0.015
                noNode.runAction(.sequence([.fadeIn(duration: self.fadeDuration)]))
                noNode.runAction(.sequence([.scale(by: 2, duration: self.fadeDuration)]))
                noNode.runAction(.sequence([.move(by: SCNVector3(0, 0, -0.405), duration: 0.1)]))
                theNode.addChildNode(noNode)
                
            }
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    
    func playTower() {
        guard let url = Bundle.main.url(forResource: isAr ? "towerar" : "toweren", withExtension: "m4a") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            try AVAudioSession.sharedInstance().setActive(true)
            
            /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
            player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.m4a.rawValue)
            
            /* iOS 10 and earlier require the following line:
             player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileTypeMPEGLayer3) */
            
            guard let player = player else { return }
            
            player.play()
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    @IBAction func btnChangeLang(_ sender: Any) {
        if !isPlaying {
            isAr = !isAr
            btnLang.setImage(UIImage(named: isAr ? "uae" : "uk"), for: .normal)
            resetTrackingConfiguration()
            for x in [tvPlaneNode, PlayButtonP1, PlayButtonP2
                , titleNode, descriptionNode, yesNode, yesNodeBg, noNode, noNodeBg, videoBg, tvPlaneNode] {
                    x.removeFromParentNode()
                    x.runAction(.fadeIn(duration: 0.1))
            }
        }
        
    }
    
}
var theNode = SCNNode()
var PlayButtonP1 = SCNNode()
var PlayButtonP2 = SCNNode()
var titleNode = SCNNode()
var descriptionNode = SCNNode()
var player: AVAudioPlayer?
var questionNode = SCNNode()
var yesNode = SCNNode()
var yesNodeBg = SCNNode()
var noNode = SCNNode()
var noNodeBg = SCNNode()
var videoBg = SCNNode()
var videoNode = SKVideoNode()
var tvPlaneNode = SCNNode()

extension ViewController: ARSCNViewDelegate {
    
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        DispatchQueue.main.async {
            guard let imageAnchor = anchor as? ARImageAnchor,
                let _ = imageAnchor.referenceImage.name else { return }
            theNode = node
            self.playTower()
            titleNode = self.getText(isAr ? "برج بابل" : "The Tower of Babel", true, UIColor(hex: "#623225"))
            titleNode.opacity = 0
            titleNode.position.x -= 0.2
            titleNode.position.z += 0.25
            titleNode.scale = SCNVector3(0.04,0.04,0.04)
            titleNode.runAction(self.fadeAndSpinAction)
            node.addChildNode(titleNode)
            
            descriptionNode = self.getText(isAr ? "الناس الذين حاولوا الوصول إلى الله!" : "The People who tried to\nreach God!")
            descriptionNode.opacity = 0
            descriptionNode.position.x -= 0.2
            descriptionNode.position.z += 0.28
            descriptionNode.scale = SCNVector3(0.02,0.02,0.02)
            descriptionNode.runAction(self.fadeAndSpinAction)
            node.addChildNode(descriptionNode)

            PlayButtonP1 = self.getButtonText()
            PlayButtonP1.opacity = 0
            PlayButtonP1.position.x -= 0.2
            PlayButtonP1.position.z -= 0.15
            PlayButtonP1.scale = SCNVector3(0.04,0.04,0.1)
            PlayButtonP1.runAction(self.fadeAndSpinAction)
            node.addChildNode(PlayButtonP1)
            
            
            let box = SCNBox(width: 0.4, height: 0.01, length: 0.06, chamferRadius: 0.06)
            box.firstMaterial?.diffuse.contents = UIColor(hex: "#F0DEB4")
            
            
            PlayButtonP2.geometry = box
            PlayButtonP2.position = PlayButtonP1.position
            PlayButtonP2.position.y -= 0.01
            PlayButtonP2.position.z -= 0.05
            PlayButtonP2.position.x += 0.19
            PlayButtonP2.opacity = 1
            PlayButtonP2.runAction(.scale(to: 1, duration: 0.0001))
            node.addChildNode(PlayButtonP2)
        }
    }//623225
    
    func getText(_ string: String, _ fancy: Bool = false, _ color: UIColor = .gray) -> SCNNode {
        let text = SCNText(string: string, extrusionDepth: 0.1)
        text.font = fancy && !isAr ? UIFont.init(name: "Savoye LET", size: 1) : (isAr ? UIFont(name: "DroidArabicKufi-Bold", size: 1) : UIFont.systemFont(ofSize: 1))
        text.flatness = 0.01
        text.firstMaterial?.diffuse.contents = color
        
        let textNode = SCNNode(geometry: text)
        
       textNode.eulerAngles.x = -.pi / 2
        return textNode
    }
    
    func getButtonText() -> SCNNode {
        let text = SCNText(string: isAr ? "--> انقر للتشغيل <--" : "--> Tap to Play <--", extrusionDepth: 0.2)
        text.font = isAr ? UIFont(name: "DroidArabicKufi-Bold", size: 1) : UIFont.systemFont(ofSize: 1)
        text.flatness = 0.01
        text.firstMaterial?.diffuse.contents = UIColor(hex: "2FCC71")
        let textNode = SCNNode(geometry: text)
        textNode.eulerAngles.x = -.pi / 2
        return textNode
    }
    
    
    
}
